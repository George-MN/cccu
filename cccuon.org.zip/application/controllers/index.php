<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Index extends CI_Controller {

    public $data;

    public function __construct() {
        parent::__construct();
        $this->load->model('data_model');
        $this->load->helper('date');
    }

    function load_view() {
        $this->load->view("inc/temp", $this->data);
    }

    public function index() {
        date_default_timezone_set('Africa/Nairobi');
        $results = $this->data_model->fetch_upcoming_events();
        // var_dump($results);
        
        $this->data ['main'] = "index";
        $this->data['events'] = $results;
        $this->load_view();
    }

    public function gallery() {
//        $this->data ['main'] = "gallery";
//        $this->load_view();
        $this->load->view("gallery");
    }

    public function message() {
        $this->load->helper('email');
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $subject = $this->input->post('subject');
        $message = $this->input->post('message');
        // echo "Details ".$name." ".$email." ".$subject." ".$message;
        if ($name && $email && $subject && $message ) {
            if (valid_email($email)) {
                $this->send_email($name . ' says ' . $subject, $message, $email, 'Comment on website');
                echo ' Thanks a lot ' . $name . '. We will get back to you soon.';
            } else {
                echo 'Please fill a valid email';
            }
        } else {
            echo 'Please fill out all the fields';
        }
    }

    public function register(){
        $this->load->helper('email');
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $phone_no = $this->input->post('phone_no');
        $email = $this->input->post('email');
        $course = $this->input->post('course');
        $reg_no = $this->input->post('reg_no');
        $gender = $this->input->post('gender');
        $hall = $this->input->post('hall');
        // echo "Details ".$first_name." ".$last_name." ".$phone_no." ".$email." ".$course." ".$reg_no." ".$gender." ".$hall;

        if ($first_name && $last_name && $phone_no && $email && $course && $reg_no && $gender && $hall) {
            if (valid_email($email)) {
                $details = array(
                    'first_name' =>$first_name ,
                     'last_name' =>$last_name ,
                      'phone_no' =>$phone_no ,
                       'email' =>$email ,
                        'course' =>$course ,
                         'reg_no' =>$reg_no ,
                          'gender' =>$gender ,
                           'hall' =>$hall ,
                );
                $result=$this->data_model->enter_data($details, 'users');
                if($result){
                    echo ' Thanks a lot ' . $first_name.' '.$last_name . ' for registering.You are now a member.';
                }else{
                      echo ' An error occurred when saving your details.Please try again.';
                }
            } else {
                echo 'Please fill a valid email';
            }
        } else {
            echo 'Please fill out all the fields';
        }
    }

    public function send_email($subject, $message, $email,$info) {
        $this->load->library('email');
        $this->email->from($email);
        $this->email->to('chiromocu@gmail.com',$info);
        $this->email->subject($subject);
        $this->email->message($message);
        $this->email->send();
    }

}
