<?php

$this->load->view("inc/header");

$this->load->view($main);

$this->load->view("inc/footer");