-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 30, 2015 at 09:36 PM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chiromocu`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL COMMENT '1 for Friday, 2 for Sunday and 3 for Special',
  `date` date NOT NULL,
  `date_to` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `speaker` varchar(255) DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `category`, `date`, `date_to`, `name`, `speaker`, `venue`, `time`) VALUES
(1, 1, '2015-02-20', '0000-00-00', 'Holy Spirit', 'Simon Kande', 'MH1', '8-10:30 pm'),
(2, 1, '2015-02-27', '0000-00-00', 'Righteousness', 'Meshack Nyatome', 'MH1', '8-10:30 pm'),
(3, 1, '2015-03-06', '0000-00-00', 'It is possible', '(CADASI committee)', 'MH1', '8-10:30pm'),
(4, 1, '2015-03-13', '0000-00-00', 'Altars', 'JOSHAT KITHUMBU', 'MH1', '8-10:30pm'),
(5, 1, '2015-03-20', '0000-00-00', 'Elders night', 'Elders', 'MH1', '8-10:30pm'),
(6, 1, '2015-03-27', '0000-00-00', 'Bereans night', 'BS $ training', 'MH1', '8-10:30pm'),
(7, 1, '2015-04-03', '0000-00-00', 'TRUE VINE', 'Pst Ken Kimiywe', 'MH1', '8-10:30pm'),
(8, 1, '2015-04-10', '0000-00-00', 'SEASONS', 'Ruth Mwanza', 'MH1', '8-10:30pm'),
(9, 1, '2015-04-17', '0000-00-00', 'ANNOINTING', 'Hogla Wanjohi', 'MH1', '8-10:30pm'),
(10, 1, '2015-04-24', '0000-00-00', 'Movie night', 'All', 'MH1', '8-10:30pm'),
(11, 2, '2015-02-22', '0000-00-00', 'Cultural Sunday', 'Evangelistic Teams', 'MH1', '8-11am'),
(12, 2, '2015-03-01', '0000-00-00', 'Fellowship', 'Ezekiel Baraza', 'MH1', '8-11am'),
(13, 2, '2015-03-08', '0000-00-00', 'MOI Sunday(identity of a man with Christ)', 'Justus Owaka', 'MH1', '8-11am'),
(14, 2, '2015-03-15', '0000-00-00', 'Forgiveness', 'Pst. Isaac', 'MH1', '8-11am'),
(15, 2, '2015-03-22', '0000-00-00', 'COMMITMENT', 'Simiyu Machani', 'MH1', '8-11am'),
(16, 2, '2015-03-29', '0000-00-00', 'Queens Sunday(The woman the well the water)', 'Dr. Ada Adoyo ', 'MH1', '8-11am'),
(17, 2, '2015-04-05', '0000-00-00', 'Associate Sunday(crucible of suffering)', 'ASAP', 'MH1', '8-11am'),
(18, 2, '2015-04-12', '0000-00-00', 'Escatology', 'Rev. Richard Mayabi', 'MH1', '8-11am'),
(19, 2, '2015-04-19', '0000-00-00', 'We call it home', 'All', 'MH1', '8-11am'),
(20, 3, '2015-02-25', '2015-03-01', 'Mini mission ', NULL, NULL, NULL),
(21, 3, '2015-02-16', '2015-02-20', 'Evangelism week', NULL, NULL, NULL),
(22, 3, '2015-03-23', '2015-03-29', 'Queens week', NULL, NULL, NULL),
(23, 3, '2015-03-28', '2015-03-28', 'Queens Saturday', NULL, NULL, NULL),
(24, 3, '2015-03-02', '2015-03-08', 'MOI week', NULL, NULL, NULL),
(25, 3, '2015-04-05', '2015-04-05', 'Baptism', NULL, NULL, NULL),
(26, 3, '2015-02-21', '2015-02-21', 'Union retreat', NULL, NULL, NULL),
(27, 3, '2015-03-07', '2015-03-07', 'Union sports day', NULL, NULL, NULL),
(28, 3, '2015-02-28', '2015-02-28', 'JCC Project', NULL, NULL, NULL),
(29, 2, '2015-06-28', '2015-06-28', 'Worship service', 'Arise Africa and Mr T', 'MH1', '8:30 am'),
(30, 3, '2015-06-28', '2015-06-28', 'Worship service', 'Arise Africa and Mr T', 'MH1', '8:30 am'),
(31, 1, '2015-07-03', '2015-07-03', 'Talents night', 'Pastor Dan', 'MH1', '8pm - 11pm');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `hall` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `phone_no`, `email`, `course`, `reg_no`, `gender`, `hall`) VALUES
(2, 'Francis chege', 'Kamau', '0702771424', 'fchege22@gmail.com', 'B.Tech', 'i39/2141/2012', 'Male', 'Chiromo'),
(3, 'Julius', 'Otieno', '0717105914', 'otienojuli@gmail.com', 'B.Sc', 'I20/2014/2014', 'Male', '2 '),
(4, 'Julius', 'Otieno', '0717105914', 'otienojuli@gmail.com', 'B.Sc', 'I20/2014/2014', 'Male', '2 '),
(5, 'Julius', 'Otieno', '0717105914', 'otienojuli@gmail.com', 'B.Sc', 'I20/2014/2014', 'Male', '2 '),
(6, 'Mutegi', 'William', '0706367677', 'mutegiwilliam30@gmail.com', 'BA.(Urban and Regional Planning)', ' ', 'Male', 'Hall 8'),
(7, 'Mutegi', 'William', '0706367677', 'mutegiwilliam30@gmail.com', 'BA.(Urban and Regional Planning)', ' School Of Built Built Environment', 'Male', 'Hall 8'),
(8, 'Mutegi', 'William', '0706367677', 'mutegiwilliam30@gmail.com', 'BA.(Urban and Regional Planning)', ' School Of Built Built Environment', 'Male', 'Hall 8'),
(9, 'Mutegi', 'William', '0706367677', 'mutegiwilliam30@gmail.com', 'BA.(Urban and Regional Planning)', ' School Of Built Built Environment', 'Male', 'Hall 8'),
(10, 'Tanin', 'Joseph', '0719537387', 'josekiroket@gmail.com', 'Bsc Biology', 'i11/1344/2013', 'Male', 'Chiromo hostels'),
(11, 'George ', 'Maina', '0786175455', 'georgemaina22@gmail.com', 'Bsc  Computer science', 'p15/1472/2013', 'Male', 'Chiromo hostels');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
